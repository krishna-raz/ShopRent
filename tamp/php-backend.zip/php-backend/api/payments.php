<?php
$db = (new Database())->connect();

$method = $_SERVER['REQUEST_METHOD'];

if ($method == 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    if (empty($data->tenantId) || empty($data->month) || !isset($data->paidAmount)) {
        http_response_code(400);
        echo json_encode(["message" => "Incomplete data"]);
        exit;
    }

    try {
        $amount = (float)$data->paidAmount;
        $month = $data->month;
        $paymentMode = $data->paymentMode ?? 'Cash';
        $notes = $data->notes ?? '';
        $paymentDate = $data->paymentDate ?? date('Y-m-d H:i:s');

        // 1. Get tenant info
        $stmt = $db->prepare("SELECT * FROM tenants WHERE id = ?");
        $stmt->execute([$data->tenantId]);
        $tenant = $stmt->fetch();

        if (!$tenant) {
            throw new Exception("Tenant not found");
        }

        $rentAmount = (float)$tenant['rent_amount'];
        $totalPaid = $amount;

        // 2. Check for existing payment for this month
        $stmt = $db->prepare("SELECT * FROM payments WHERE tenant_id = ? AND month = ?");
        $stmt->execute([$data->tenantId, $month]);
        $payment = $stmt->fetch();

        $paymentId = null;

        if ($payment) {
            $totalPaid = (float)$payment['paid_amount'] + $amount;
            $dueAmount = max(0, $rentAmount - $totalPaid);
            $status = ($totalPaid >= $rentAmount) ? 'Paid' : (($totalPaid > 0) ? 'Partial' : 'Pending');
            $paymentId = $payment['id'];

            $stmt = $db->prepare("UPDATE payments SET paid_amount = ?, due_amount = ?, status = ?, payment_date = ?, payment_mode = ? WHERE id = ?");
            $stmt->execute([$totalPaid, $dueAmount, $status, $paymentDate, $paymentMode, $payment['id']]);
        } else {
            $dueAmount = max(0, $rentAmount - $totalPaid);
            $status = ($totalPaid >= $rentAmount) ? 'Paid' : (($totalPaid > 0) ? 'Partial' : 'Pending');

            $stmt = $db->prepare("INSERT INTO payments (tenant_id, tenant_name, shop_number, month, rent_amount, paid_amount, due_amount, status, payment_date, payment_mode, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$data->tenantId, $tenant['tenant_name'], $tenant['shop_number'], $month, $rentAmount, $totalPaid, $dueAmount, $status, $paymentDate, $paymentMode, $notes]);
            $paymentId = $db->lastInsertId();
        }

        // 3. ALWAYS create a separate transaction history entry
        $stmt = $db->prepare("INSERT INTO payment_transactions (payment_id, tenant_id, tenant_name, shop_number, month, rent_amount, transaction_amount, paid_amount, remaining_due, status, payment_mode, notes, date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$paymentId, $data->tenantId, $tenant['tenant_name'], $tenant['shop_number'], $month, $rentAmount, $amount, $totalPaid, $dueAmount, $status, $paymentMode, $notes, $paymentDate]);

        echo json_encode([
            "message" => "Payment recorded successfully",
            "_id" => (string)$paymentId,
            "totalPaid" => $totalPaid,
            "dueAmount" => $dueAmount,
            "status" => $status
        ]);

    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(["message" => "Error: " . $e->getMessage()]);
    }
} elseif ($method == 'GET') {
    $action = $parts[1] ?? '';

    if ($action == 'transactions') {
        // Get all individual payment transactions
        $stmt = $db->query("SELECT * FROM payment_transactions ORDER BY date ASC");
        $transactions = $stmt->fetchAll();
        foreach ($transactions as &$t) {
            $t['_id'] = (string)$t['id'];
            $t['tenantId'] = (string)$t['tenant_id'];
            $t['paymentId'] = $t['payment_id'] ? (string)$t['payment_id'] : null;
        }
        echo json_encode($transactions);
    } elseif ($action == 'pending-dues') {
        $stmt = $db->query("SELECT p.*, t.tenant_name, t.phone, t.shop_number, t.status as tenant_status FROM payments p LEFT JOIN tenants t ON p.tenant_id = t.id WHERE p.status != 'Paid' ORDER BY p.payment_date DESC");
        $payments = $stmt->fetchAll();
        echo json_encode($payments);
    } elseif ($action == 'tenant' && isset($parts[2])) {
        $stmt = $db->prepare("SELECT * FROM payments WHERE tenant_id = ? ORDER BY payment_date DESC");
        $stmt->execute([$parts[2]]);
        $payments = $stmt->fetchAll();
        foreach ($payments as &$p) {
            $p['_id'] = (string)$p['id'];
        }
        echo json_encode($payments);
    } else {
        // Get all merged monthly payments
        $tenantId = $_GET['tenantId'] ?? null;
        $status = $_GET['status'] ?? null;
        $month = $_GET['month'] ?? null;

        $sql = "SELECT p.*, t.tenant_name, t.phone, t.shop_number FROM payments p LEFT JOIN tenants t ON p.tenant_id = t.id WHERE 1=1";
        $params = [];

        if ($tenantId) {
            $sql .= " AND p.tenant_id = ?";
            $params[] = $tenantId;
        }
        if ($status) {
            $sql .= " AND p.status = ?";
            $params[] = $status;
        }
        if ($month) {
            $sql .= " AND p.month = ?";
            $params[] = $month;
        }

        $sql .= " ORDER BY p.payment_date DESC";

        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $payments = $stmt->fetchAll();
        foreach ($payments as &$p) {
            $p['_id'] = (string)$p['id'];
        }
        echo json_encode($payments);
    }
}
?>
