<?php
$db = (new Database())->connect();

$method = $_SERVER['REQUEST_METHOD'];

if ($method == 'GET') {
    $action = $parts[1] ?? '';

    // Get counts
    $totalShops = $db->query("SELECT COUNT(*) FROM shops")->fetchColumn();
    $occupiedShops = $db->query("SELECT COUNT(*) FROM shops WHERE occupancy_status = 'Occupied'")->fetchColumn();
    $totalTenants = $db->query("SELECT COUNT(*) FROM tenants WHERE status = 'Active'")->fetchColumn();
    $inactiveTenants = $db->query("SELECT COUNT(*) FROM tenants WHERE status = 'Inactive'")->fetchColumn();

    // Get deposit metrics
    $activeDeposits = $db->query("SELECT COUNT(*) FROM tenants WHERE deposit_status = 'Active'")->fetchColumn();
    $totalDepositsHeld = $db->query("SELECT SUM(security_deposit) FROM tenants WHERE deposit_status = 'Active'")->fetchColumn() ?? 0;
    $totalRefundableAmount = $db->query("SELECT SUM(refundable_amount) FROM tenants WHERE deposit_status = 'Active'")->fetchColumn() ?? 0;
    $totalRefunded = $db->query("SELECT SUM(amount) FROM deposit_transactions WHERE type = 'Refund'")->fetchColumn() ?? 0;

    // Get financial metrics
    $monthlyRevenue = $db->query("SELECT SUM(paid_amount) FROM payments WHERE status IN ('Paid', 'Partial')")->fetchColumn() ?? 0;
    $totalPendingDues = $db->query("SELECT SUM(due_amount) FROM payments WHERE status != 'Paid'")->fetchColumn() ?? 0;

    if ($action == 'stats') {
        echo json_encode([
            "totalShops" => (int)$totalShops,
            "occupiedShops" => (int)$occupiedShops,
            "vacantShops" => (int)($totalShops - $occupiedShops),
            "totalTenants" => (int)$totalTenants,
            "monthlyRevenue" => (float)$monthlyRevenue,
            "totalPendingDues" => (float)$totalPendingDues
        ]);
    } else {
        // Full dashboard data
        $recentActivities = $db->query("SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 10")->fetchAll();
        $recentPayments = $db->query("SELECT p.*, t.tenant_name FROM payments p LEFT JOIN tenants t ON p.tenant_id = t.id ORDER BY p.payment_date DESC LIMIT 5")->fetchAll();

        echo json_encode([
            "deposits" => [
                "totalDepositsHeld" => (float)$totalDepositsHeld,
                "totalRefundableAmount" => (float)$totalRefundableAmount,
                "totalRefunded" => (float)$totalRefunded,
                "activeDepositsCount" => (int)$activeDeposits
            ],
            "shops" => [
                "total" => (int)$totalShops,
                "occupied" => (int)$occupiedShops,
                "vacant" => (int)($totalShops - $occupiedShops)
            ],
            "tenants" => [
                "total" => (int)($totalTenants + $inactiveTenants),
                "active" => (int)$totalTenants,
                "inactive" => (int)$inactiveTenants
            ],
            "financial" => [
                "monthlyRevenue" => (float)$monthlyRevenue,
                "totalPendingDues" => (float)$totalPendingDues
            ],
            "recentActivities" => $recentActivities,
            "recentPayments" => $recentPayments
        ]);
    }
}
?>
