<?php
$db = (new Database())->connect();

$method = $_SERVER['REQUEST_METHOD'];

if ($method == 'GET') {
    $tenantId = $_GET['tenantId'] ?? null;

    if ($tenantId) {
        $stmt = $db->prepare("SELECT * FROM deposit_transactions WHERE tenant_id = ? ORDER BY date DESC");
        $stmt->execute([$tenantId]);
    } else {
        $stmt = $db->query("SELECT * FROM deposit_transactions ORDER BY date DESC");
    }
    $transactions = $stmt->fetchAll();
    foreach ($transactions as &$t) {
        $t['_id'] = (string)$t['id'];
        $t['tenantId'] = (string)$t['tenant_id'];
    }
    echo json_encode($transactions);
}
?>
