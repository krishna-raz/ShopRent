<?php
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

$db = (new Database())->connect();
$secret_key = "yoursecretkey";

$method = $_SERVER['REQUEST_METHOD'];

if ($method == 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    $action = $parts[1] ?? '';

    if ($action == 'login') {
        if (empty($data->email) || empty($data->password)) {
            http_response_code(400);
            echo json_encode(["message" => "Email and password required"]);
            exit;
        }

        $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$data->email]);
        $user = $stmt->fetch();

        if ($user && password_verify($data->password, $user->password)) {
            $payload = [
                "iss" => "shoprent",
                "aud" => "shoprent_users",
                "iat" => time(),
                "exp" => time() + (60 * 60 * 24),
                "data" => [
                    "id" => (string)$user->id,
                    "email" => $user->email,
                    "role" => $user->role ?? 'Admin'
                ]
            ];

            $jwt = JWT::encode($payload, $secret_key, 'HS256');

            echo json_encode([
                "token" => $jwt,
                "user" => [
                    "_id" => (string)$user->id,
                    "name" => $user->name,
                    "email" => $user->email,
                    "role" => $user->role ?? 'Admin'
                ]
            ]);
        } else {
            http_response_code(401);
            echo json_encode(["message" => "Invalid credentials"]);
        }
    } elseif ($action == 'register') {
        $hashedPassword = password_hash($data->password, PASSWORD_BCRYPT);
        $stmt = $db->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->execute([$data->name, $data->email, $hashedPassword, $data->role ?? 'Admin']);
        echo json_encode(["message" => "User registered successfully"]);
    } elseif ($action == 'me') {
        $authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
        if (preg_match('/Bearer\s+(.*)$/i', $authHeader, $matches)) {
            try {
                $decoded = JWT::decode($matches[1], new Key($secret_key, 'HS256'));
                $stmt = $db->prepare("SELECT id, name, email, role FROM users WHERE id = ?");
                $stmt->execute([$decoded->data->id]);
                $user = $stmt->fetch();
                if ($user) {
                    echo json_encode([
                        "_id" => (string)$user->id,
                        "name" => $user->name,
                        "email" => $user->email,
                        "role" => $user->role
                    ]);
                } else {
                    http_response_code(404);
                    echo json_encode(["message" => "User not found"]);
                }
            } catch (Exception $e) {
                http_response_code(401);
                echo json_encode(["message" => "Invalid token"]);
            }
        } else {
            http_response_code(401);
            echo json_encode(["message" => "Authorization required"]);
        }
    }
} elseif ($method == 'GET' && $parts[1] == 'users') {
    $stmt = $db->query("SELECT id, name, email, role, created_at FROM users");
    $users = $stmt->fetchAll();
    foreach ($users as &$u) {
        $u['_id'] = (string)$u['id'];
    }
    echo json_encode($users);
}
?>
