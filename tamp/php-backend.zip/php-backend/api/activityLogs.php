<?php
$db = (new Database())->connect();

$method = $_SERVER['REQUEST_METHOD'];

if ($method == 'GET') {
    $stmt = $db->query("SELECT al.*, u.name as performed_by_name FROM activity_logs al LEFT JOIN users u ON al.performed_by = u.id ORDER BY al.created_at DESC LIMIT 50");
    $logs = $stmt->fetchAll();
    foreach ($logs as &$l) {
        $l['_id'] = (string)$l['id'];
    }
    echo json_encode($logs);
} elseif ($method == 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    $stmt = $db->prepare("INSERT INTO activity_logs (action, description, entity_type, entity_id, performed_by) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$data->action, $data->description, $data->entityType ?? 'System', $data->entityId ?? null, $data->performedBy ?? null]);
    echo json_encode(["message" => "Activity logged", "_id" => (string)$db->lastInsertId()]);
}
?>
