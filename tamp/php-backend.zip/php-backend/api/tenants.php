<?php
$db = (new Database())->connect();

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if ($id) {
            $stmt = $db->prepare("SELECT t.*, s.shop_number, s.shop_name FROM tenants t LEFT JOIN shops s ON t.shop_id = s.id WHERE t.id = ?");
            $stmt->execute([$id]);
            $tenant = $stmt->fetch();
            if ($tenant) {
                $tenant['_id'] = (string)$tenant['id'];
                $tenant['shopId'] = (string)$tenant['shop_id'];
                echo json_encode($tenant);
            } else {
                http_response_code(404);
                echo json_encode(["message" => "Tenant not found"]);
            }
        } else {
            $stmt = $db->query("SELECT t.*, s.shop_number, s.shop_name FROM tenants t LEFT JOIN shops s ON t.shop_id = s.id ORDER BY t.created_at DESC");
            $tenants = $stmt->fetchAll();
            foreach ($tenants as &$t) {
                $t['_id'] = (string)$t['id'];
                $t['shopId'] = (string)$t['shop_id'];
            }
            echo json_encode($tenants);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"));

        // 1. Create Tenant
        $stmt = $db->prepare("INSERT INTO tenants (tenant_name, phone, aadhaar, address, shop_id, shop_number, rent_amount, joining_date, security_deposit, refundable_amount, deposit_status, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active', 'Active')");
        $stmt->execute([
            $data->tenantName,
            $data->phone,
            $data->aadhaar ?? '',
            $data->address ?? '',
            $data->shopId,
            $data->shopNumber,
            $data->rentAmount,
            $data->joiningDate,
            $data->securityDeposit,
            $data->securityDeposit
        ]);
        $newTenantId = $db->lastInsertId();

        // 2. Update Shop
        $stmt = $db->prepare("UPDATE shops SET occupancy_status = 'Occupied', tenant_id = ? WHERE id = ?");
        $stmt->execute([$newTenantId, $data->shopId]);

        // 3. Record Deposit Transaction
        $stmt = $db->prepare("INSERT INTO deposit_transactions (tenant_id, tenant_name, shop_number, type, amount, reason, balance_before, balance_after) VALUES (?, ?, ?, 'Collection', ?, 'Initial deposit on tenant onboarding', 0, ?)");
        $stmt->execute([$newTenantId, $data->tenantName, $data->shopNumber, $data->securityDeposit, $data->securityDeposit]);

        echo json_encode(["message" => "Tenant created successfully", "_id" => (string)$newTenantId]);
        break;

    case 'PUT':
        if (!$id) {
            http_response_code(400);
            echo json_encode(["message" => "ID required"]);
            exit;
        }

        $data = json_decode(file_get_contents("php://input"));
        $action = $parts[2] ?? '';

        if ($action == 'refund') {
            $stmt = $db->prepare("SELECT * FROM tenants WHERE id = ?");
            $stmt->execute([$id]);
            $tenant = $stmt->fetch();

            if (!$tenant) {
                http_response_code(404);
                echo json_encode(["message" => "Tenant not found"]);
                exit;
            }

            $deductionAmount = (float)($data->deductionAmount ?? 0);
            $reason = $data->deductionReason ?? 'Adjustment';
            $balanceBefore = (float)$tenant['refundable_amount'];
            $newRefundable = max(0, $balanceBefore - $deductionAmount);

            $status = 'Active';
            if ($newRefundable == 0 && $deductionAmount > 0) $status = 'Deducted';
            elseif ($deductionAmount > 0 && $newRefundable > 0) $status = 'Partial Refund';
            elseif ($deductionAmount == 0 && $newRefundable == 0) $status = 'Refunded';

            $stmt = $db->prepare("UPDATE tenants SET refundable_amount = ?, deposit_status = ?, refund_date = NOW() WHERE id = ?");
            $stmt->execute([$newRefundable, $status, $id]);

            if ($status == 'Refunded' || $status == 'Deducted') {
                $stmt = $db->prepare("UPDATE shops SET occupancy_status = 'Vacant', tenant_id = NULL WHERE id = ?");
                $stmt->execute([$tenant['shop_id']]);
                $stmt = $db->prepare("UPDATE tenants SET status = 'Inactive' WHERE id = ?");
                $stmt->execute([$id]);
            }

            $txType = $deductionAmount > 0 ? 'Deduction' : 'Refund';
            $stmt = $db->prepare("INSERT INTO deposit_transactions (tenant_id, tenant_name, shop_number, type, amount, reason, balance_before, balance_after) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$id, $tenant['tenant_name'], $tenant['shop_number'], $txType, $deductionAmount, $reason, $balanceBefore, $newRefundable]);

            echo json_encode(["message" => "Deposit adjustment processed"]);
        } else {
            $updateFields = [];
            $params = [];
            $allowedFields = ['tenant_name', 'phone', 'aadhaar', 'address', 'shop_id', 'shop_number', 'rent_amount', 'joining_date', 'security_deposit', 'refundable_amount', 'deposit_status', 'status'];

            foreach ($data as $key => $value) {
                $dbKey = preg_replace('/([A-Z])/', '_$1', $key);
                $dbKey = strtolower($dbKey);
                if (in_array($dbKey, $allowedFields)) {
                    $updateFields[] = "$dbKey = ?";
                    $params[] = $value;
                }
            }

            if (!empty($updateFields)) {
                $params[] = $id;
                $stmt = $db->prepare("UPDATE tenants SET " . implode(', ', $updateFields) . " WHERE id = ?");
                $stmt->execute($params);
            }

            echo json_encode(["message" => "Tenant updated"]);
        }
        break;

    case 'DELETE':
        if (!$id) {
            http_response_code(400);
            echo json_encode(["message" => "ID required"]);
            exit;
        }
        $stmt = $db->prepare("SELECT shop_id FROM tenants WHERE id = ?");
        $stmt->execute([$id]);
        $tenant = $stmt->fetch();
        if ($tenant && $tenant['shop_id']) {
            $stmt = $db->prepare("UPDATE shops SET occupancy_status = 'Vacant', tenant_id = NULL WHERE id = ?");
            $stmt->execute([$tenant['shop_id']]);
        }
        $stmt = $db->prepare("DELETE FROM tenants WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(["message" => "Tenant deleted and shop vacated"]);
        break;
}
?>
