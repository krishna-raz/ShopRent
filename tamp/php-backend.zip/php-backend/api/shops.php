<?php
$db = (new Database())->connect();

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        if ($id) {
            $stmt = $db->prepare("SELECT * FROM shops WHERE id = ?");
            $stmt->execute([$id]);
            $shop = $stmt->fetch();
            if ($shop) {
                $shop['_id'] = (string)$shop['id'];
                echo json_encode($shop);
            } else {
                http_response_code(404);
                echo json_encode(["message" => "Shop not found"]);
            }
        } else {
            $stmt = $db->query("SELECT * FROM shops ORDER BY created_at DESC");
            $shops = $stmt->fetchAll();
            foreach ($shops as &$s) {
                $s['_id'] = (string)$s['id'];
            }
            echo json_encode($shops);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"));

        $stmt = $db->prepare("SELECT id FROM shops WHERE shop_number = ?");
        $stmt->execute([$data->shopNumber]);
        if ($stmt->fetch()) {
            http_response_code(400);
            echo json_encode(["message" => "Shop number already exists"]);
            exit;
        }

        $stmt = $db->prepare("INSERT INTO shops (shop_number, shop_name, floor, monthly_rent) VALUES (?, ?, ?, ?)");
        $stmt->execute([$data->shopNumber, $data->shopName ?? 'Unnamed Shop', $data->floor, $data->monthlyRent]);
        $newId = $db->lastInsertId();

        echo json_encode(["message" => "Shop created", "_id" => (string)$newId]);
        break;

    case 'PUT':
        if (!$id) {
            http_response_code(400);
            echo json_encode(["message" => "ID required"]);
            exit;
        }
        $data = json_decode(file_get_contents("php://input"));
        $updateFields = [];
        $params = [];

        $allowedFields = ['shop_number', 'shop_name', 'floor', 'monthly_rent', 'occupancy_status', 'tenant_id'];
        foreach ($data as $key => $value) {
            $dbKey = preg_replace('/([A-Z])/', '_$1', $key);
            $dbKey = strtolower($dbKey);
            if (in_array($dbKey, $allowedFields)) {
                $updateFields[] = "$dbKey = ?";
                $params[] = $value;
            }
        }

        if (!empty($updateFields)) {
            $params[] = $id;
            $stmt = $db->prepare("UPDATE shops SET " . implode(', ', $updateFields) . " WHERE id = ?");
            $stmt->execute($params);
        }

        echo json_encode(["message" => "Shop updated"]);
        break;

    case 'DELETE':
        if (!$id) {
            http_response_code(400);
            echo json_encode(["message" => "ID required"]);
            exit;
        }
        $stmt = $db->prepare("DELETE FROM shops WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(["message" => "Shop deleted"]);
        break;
}
?>
